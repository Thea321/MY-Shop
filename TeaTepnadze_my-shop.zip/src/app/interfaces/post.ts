export interface Post {
    userIs: number,
    id: number,
    title: string,
    body: string

}
