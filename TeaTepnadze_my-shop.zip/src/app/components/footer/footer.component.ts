import { HttpClient } from '@angular/common/http';
import { Component } from '@angular/core';

@Component({
  selector: 'app-footer',
  imports: [],
  templateUrl: './footer.component.html',
  styleUrl: './footer.component.css'
})
export class FooterComponent {

  //apiURL: string = "https://jsonplaceholder.typicode.com/posts";
  //constructor(private http: HttpClient) {}

  //fetchData() {
    //this.http.get(this.apiURL).subscribe((data) => {console.log(data); });
  //}

  ngOnInit() {
    //this.fetchData();
  }

}
