import { Component } from '@angular/core';

@Component({
  selector: 'app-details-reviews',
  imports: [],
  templateUrl: './details-reviews.component.html',
  styleUrl: './details-reviews.component.css'
})
export class DetailsReviewsComponent {

}
