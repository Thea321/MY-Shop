import { ProfitPipe } from './profit.pipe';

describe('ProfitPipe', () => {
  it('create an instance', () => {
    const pipe = new ProfitPipe();
    expect(pipe).toBeTruthy();
  });
});
