import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Post } from '../interfaces/post';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class DataService {
  //apiURL: string = "https://jsonplaceholder.typicode.com/posts";
  apiURL: string = "https://jsonplaceholder.typicode.com";
  



  constructor(private http: HttpClient) { }

  getAllPosts(): Observable<Post[]> {
    return forkJoin([ob1,ob2])
    this.http.get<Post[]>(this.apiURL + "/posts");
    this.http.get<Post[]>(this.apiURL + "/userss");
    
  }
}
